# @eva_solutions/auth-sdk

> Official TypeScript client for the EVA Auth Service — secure cookie-based auth with JWT ES256, JWKS rotation, S2S signing, and webhooks.

[![npm version](https://img.shields.io/npm/v/@eva_solutions/auth-sdk)](https://www.npmjs.com/package/@eva_solutions/auth-sdk)
[![npm downloads](https://img.shields.io/npm/dm/@eva_solutions/auth-sdk)](https://www.npmjs.com/package/@eva_solutions/auth-sdk)
[![license MIT](https://img.shields.io/npm/l/@eva_solutions/auth-sdk)](./LICENSE)
[![CI status](https://github.com/eva-solutions-org/auth-sdk/actions/workflows/ci.yml/badge.svg)](https://github.com/eva-solutions-org/auth-sdk/actions/workflows/ci.yml)
[![Provenance](https://img.shields.io/badge/Provenance-%E2%9C%93-blue)](https://docs.npmjs.com/generating-provenance-statements)
[![bundle size](https://img.shields.io/bundlephobia/minzip/@eva_solutions/auth-sdk)](https://bundlephobia.com/package/@eva_solutions/auth-sdk)

---

`@eva_solutions/auth-sdk` is the official TypeScript client for the EVA Auth Service. It handles the full authentication lifecycle — OTP login, secure cookie-based session management, automatic token refresh, and JWT verification with ES256 + JWKS rotation — so application code stays clean.

The SDK bridges two transport layers: HttpOnly cookies between the React frontend and the Hono backend, and custom headers between the backend and the EVA Auth Service. Neither layer is visible to consumers.

It ships as tree-shakeable ESM + CJS with TypeScript declarations, sourcemaps, and zero runtime dependencies on heavy frameworks. Pick only the entry points you need.

## Features

- JWT verification with ES256 + automatic JWKS rotation (24 h cache, 30 s refetch cooldown)
- Secure HttpOnly cookie session management — no tokens exposed to JavaScript
- React hooks for client-side auth state (`useAuth`, `useUser`, `useSessions`, `useEmpresas`)
- Hono middleware and pre-built auth routes for server-side route protection
- S2S (service-to-service) client with automatic HMAC canonical signing
- Webhook event verification (HMAC-SHA256 with timestamp window)
- Built-in error handling with `Result<T>` pattern — no thrown exceptions for business flows
- Tree-shakeable ESM + CJS + `.d.ts` with declaration maps and sourcemaps
- 9 independent entry points — import only what your runtime needs
- Typed extra JWT claims via optional Zod schema (`extraClaimsSchema`)
- One npm package for every environment — the Auth Service URL is set at boot with `configureEvaAuth({ authUrl })`

---

## Installation

```bash
pnpm add @eva_solutions/auth-sdk
# or
npm install @eva_solutions/auth-sdk
# or
yarn add @eva_solutions/auth-sdk
```

**Optional peer dependencies** — install only the peers you need:

```bash
pnpm add hono              # required for @eva_solutions/auth-sdk/hono
pnpm add react             # required for @eva_solutions/auth-sdk/react
pnpm add @hono/zod-openapi # required for @eva_solutions/auth-sdk/hono-openapi
```

---

## Quick Start

### Server — Hono

```ts
import { Hono } from 'hono';
import { configureEvaAuth } from '@eva_solutions/auth-sdk';
import { evaAuth, evaAuthRoutes } from '@eva_solutions/auth-sdk/hono';

configureEvaAuth({ authUrl: process.env.AUTH_URL }); // once at boot, before the first request

const app = new Hono();

app.route('/auth', evaAuthRoutes()); // pre-built login / logout / me routes
app.use('/api/*', evaAuth());         // protect routes — verifies JWT, auto-refreshes

app.get('/api/me', (c) => {
  const { id, sessionId } = c.var.evaPayload;
  return c.json({ id, sessionId });
});
```

> `authUrl` is required before the first request that needs the Auth Service. If it is missing, those calls throw a configuration error (HTTP 500, never 401). See [Configuration](#configuration) below.

Typed extra JWT claims:

```ts
import { z } from 'zod';
import { evaAuth } from '@eva_solutions/auth-sdk/hono';

const auth = evaAuth({
  extraClaimsSchema: z.object({
    phone: z.string(),
    empresaId: z.string().uuid(),
  }),
});

app.use('/api/*', auth);
```

### Client — React

```tsx
import { useState } from 'react';
import { EvaAuthProvider, useAuth, useUser } from '@eva_solutions/auth-sdk/react';

function App() {
  return (
    <EvaAuthProvider basePath="/auth">
      <Profile />
    </EvaAuthProvider>
  );
}

function Profile() {
  const { isAuthenticated, isLoading, login, logout } = useAuth();
  const { data: user } = useUser();
  // Two-step OTP login: keep the challengeId in memory between the steps.
  const [challengeId, setChallengeId] = useState<string>();

  if (isLoading) return <p>Loading...</p>;
  if (!isAuthenticated) {
    const phone = '+1555000000';
    return challengeId ? (
      <button onClick={() => login.verify({ phone, code: '123456', challengeId })}>
        Verify code
      </button>
    ) : (
      <button
        onClick={async () => {
          const res = await login.getCode({ phone });
          if (res.ok) setChallengeId(res.data.challengeId);
        }}
      >
        Sign in
      </button>
    );
  }

  return (
    <div>
      <p>Hello, {user?.name}</p>
      <button onClick={logout}>Sign out</button>
    </div>
  );
}
```

> **OTP login needs a `challengeId`.** `get-code` returns `{ data: { message, challengeId } }` and `/login` (and `login.verify`) requires that `challengeId` together with the code. Keep it in memory between the two calls; a new `get-code` invalidates the previous one. A login without it fails with `400`. Coming from 2.x? See the [migration guide](../../docs/migration.md#8-login-otp-requiere-challengeid).

### Generic Runtime (non-Hono backends)

```ts
import { verifyRequest } from '@eva_solutions/auth-sdk/generic';

const result = await verifyRequest(request); // standard Web API Request

if (!result.ok) {
  return new Response('Unauthorized', { status: 401 });
}

const { payload, newCookies } = result.data;
// payload.id, payload.sessionId
// newCookies: string[] | undefined — forward to Set-Cookie if present
```

### Service-to-Service (S2S signing)

```ts
import { createS2SClient } from '@eva_solutions/auth-sdk/s2s';

const s2s = createS2SClient({
  clientId: 'my-service',
  secretHex: process.env.S2S_SECRET!,
  baseUrl: 'https://auth.example.com',
});

// All requests are automatically signed with HMAC
const user = await s2s.getUser('user-id-123');
```

Low-level signing (when you need manual control). `signS2SHeaders` returns the four
required headers (`x-eva-client-id`, `x-eva-timestamp`, `x-eva-nonce`, `x-eva-signature`);
each call generates a fresh nonce:

```ts
import { signS2SHeaders } from '@eva_solutions/auth-sdk/s2s';

const bodyBytes = new TextEncoder().encode(JSON.stringify({ ids: ['user-id-123'] }));
const headers = await signS2SHeaders({
  method: 'POST',
  path: '/api/v1/internal/users/batch',
  bodyBytes,
  clientId: 'my-service',
  secretHex: process.env.S2S_SECRET!,
});

await fetch('https://auth.example.com/api/v1/internal/users/batch', {
  method: 'POST',
  headers: { 'content-type': 'application/json', ...headers },
  body: bodyBytes,
});
```

### Verifying inbound S2S requests

If your service receives requests signed via `createS2SClient`, `signS2SHeaders` or `signS2SRequest`,
use the server-side verification primitives to authenticate them.

#### Hono middleware (recommended for Hono apps)

```ts
import { Hono } from 'hono'
import { s2sAuth, requireScope } from '@eva_solutions/auth-sdk/hono'

const app = new Hono()

app.use('*', s2sAuth({
  secretStore: async (clientId) => {
    const client = await db.serviceClients.findBySlug(clientId)
    return client?.secret ?? null
  },
  scopesOf: async (clientId) => {
    const client = await db.serviceClients.findBySlug(clientId)
    return client?.scopes ?? []
  },
  onAuth: (clientId, scopes) => {
    logger.info({ clientId, scopes }, 's2s authenticated')
  },
}))

app.use('/admin/*', requireScope('admin'))

app.post('/internal/users', async (c) => {
  const clientId = c.get('s2sClientId')
  // ... handle request
})
```

On verification failure: responds with HTTP 401 and body `{ error: { code, message } }`.
On scope failure: responds with HTTP 403 and body `{ error: { code: 'insufficient_scope', required: '<scope>' } }`.

**Multi-scope (v1.1.0+)**:

```ts
// AND — all scopes must be present
app.get('/admin/audit', s2sAuth(opts), requireScope({ all: ['admin', 'audit'] }), handler)
// 403 if missing any: { error: { code: 'insufficient_scope', requiredAll: [...], missing: [...] } }

// OR — at least one scope must be present
app.get('/data', s2sAuth(opts), requireScope({ any: ['data:read', 'data:write'] }), handler)
// 403 if none: { error: { code: 'insufficient_scope', requiredAny: [...] } }
```

Setup-time validation: empty arrays, empty objects, and mixed `{ all, any }` throw `TypeError` immediately when constructing the middleware.

#### Framework-agnostic (Web API Request)

```ts
import { verifyS2SRequest } from '@eva_solutions/auth-sdk/s2s'

const result = await verifyS2SRequest(request, {
  secretStore: async (clientId) => lookupSecret(clientId),
})

if (!result.ok) {
  return new Response(JSON.stringify({ error: result.error }), {
    status: 401,
    headers: { 'content-type': 'application/json' },
  })
}

const { clientId } = result.data
```

#### Replay protection (built-in)

Provide a `replayCache` callback to `verifyS2SRequest` (or `s2sAuth`) for atomic
nonce-based replay protection (every S2S request carries a unique `x-eva-nonce`; the SDK passes the key `${clientId}:${nonce}` and a TTL of `2 * timestampWindowSeconds + 1`, 241 s by default):

```ts
import { Redis } from 'ioredis'
const redis = new Redis(/* ... */)

const replayCache = {
  async setIfAbsent(key: string, ttlSeconds: number): Promise<boolean> {
    const result = await redis.set(key, '1', 'EX', ttlSeconds, 'NX')
    return result === 'OK' // null when key existed (replay detected)
  },
}

const result = await verifyS2SRequest(request, { secretStore, replayCache })
if (!result.ok) return /* handle */
```

The `replayCache.setIfAbsent` callback is **store-agnostic** — wrap Redis, Memcached, an
in-memory `Map`, or any backend that can atomically check-and-set with TTL.

> **Note**: the `replayCache` store should be **shared across all instances of your
> service** for the same `clientId`/secret pair to prevent cross-instance replay.

If `setIfAbsent` rejects (e.g. store unreachable), the error propagates — the SDK
treats store failure as **fail-closed** (no degraded mode).

#### Performance benchmarks (optional)

For empirical timing data of `verifyS2SRequest`, run the on-demand benchmark:

```bash
pnpm exec vitest bench tests/perf/s2s-timing.bench.ts
```

This benchmark is not part of CI by default — use it locally to capture
baseline timing and detect performance regressions when modifying
`verifyS2SRequest` or `buildS2SCanonicalString`.

---

### Webhook Verification

```ts
import { verifyWebhookSignature } from '@eva_solutions/auth-sdk/webhooks';

const isValid = await verifyWebhookSignature({
  payload: req.body,          // raw string body
  signature: req.headers['x-eva-signature']!,
  secret: process.env.WEBHOOK_SECRET!,
  timestamp: req.headers['x-eva-timestamp']!,
});

if (!isValid) return new Response('Forbidden', { status: 403 });
```

---

## Configuration

```ts
import { configureEvaAuth } from '@eva_solutions/auth-sdk';

// Call once at application boot, before the first request
configureEvaAuth({
  authUrl: 'https://auth.example.com',  // required — Auth Service URL (see below)
  cookieDomain: '.example.com',         // share cookies across subdomains
  errorWire: 'api',                     // 'api' (default) | 'string' (legacy 0.x compat)
  errorMessages: {                      // optional — override SDK error messages
    authRequired: 'Authentication required',
  },
});
```

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `authUrl` | `string` | — (required) | Base URL of the Auth Service. Immutable once set. |
| `cookieDomain` | `string` | `undefined` | Cookie `Domain` attribute — use `'.example.com'` for subdomain sharing. |
| `errorWire` | `'api' \| 'string'` | `'api'` | Wire shape for 4xx responses. `'api'` emits `{ error: { code, message } }`. `'string'` emits `{ error: string }` (legacy). |
| `errorMessages` | `Partial<EvaErrorMessages>` | built-in defaults | Granular override of SDK error messages (16 keys). Unknown keys throw. |

The Auth Service URL is configured at runtime with `authUrl`, once at boot, before the first request that needs the Auth Service. One package serves every environment.

- Accepted: `https://host` (a path is allowed), or `http` only on loopback (`localhost`, `127.0.0.1`, `[::1]`).
- Rejected (throws, without echoing the value): remote `http`, malformed values, userinfo, query and fragment.
- Immutable: the same value again is a no-op, a different value throws.
- If it is missing, the calls that need it throw a configuration error (`EvaAuthConfigError`): answer **500**, never 401.
- Auth cookies are always `Secure`. Safari drops them on `http://localhost`, so use https in local development.

For full configuration details see [docs/configuration.md](../../docs/configuration.md).

---

## Entry Points

The SDK exports 9 independent entry points. Import only what your runtime needs.

| Import | Description | Required peer |
|--------|-------------|---------------|
| `@eva_solutions/auth-sdk` | Core: client factory, JWT verify, JWKS, error system, types, constants | — |
| `@eva_solutions/auth-sdk/hono` | `evaAuth()` middleware, `evaAuthRoutes()`, helpers, cookies | `hono >=4.12.19` |
| `@eva_solutions/auth-sdk/react` | `EvaAuthProvider`, `useAuth`, `useUser`, `useSessions`, `useEmpresas`, `authFetch` | `react >=19.2.6` |
| `@eva_solutions/auth-sdk/generic` | `verifyRequest()`, `setTokenCookies()`, `clearTokenCookies()` — Web API `Request` | — |
| `@eva_solutions/auth-sdk/hono-openapi` | `evaAuthOpenAPIRoutes()` — OpenAPI 3.1 variant with `/doc` | `hono >=4.12.19`, `@hono/zod-openapi >=1.4.0` |
| `@eva_solutions/auth-sdk/webhooks` | `verifyWebhookSignature()`, `EVENT_CODES`, webhook types | — |
| `@eva_solutions/auth-sdk/admin` | `createAdminClient()` — service clients and user management | — |
| `@eva_solutions/auth-sdk/s2s` | `createS2SClient()`, `signS2SHeaders()`, `signS2SRequest()` — HMAC S2S signing | — |
| `@eva_solutions/auth-sdk/contracts` | Shared wire contract of the Auth API: error and login schemas, `ERROR_CODES`, header names, `AUTH_ROUTES`. Used by the Auth API; the consumer must resolve a single `zod` copy. See [docs/api.md](../../docs/api.md#eva_solutionsauth-sdkcontracts) | — |

---

## JWT Configuration

The SDK verifies tokens issued by the EVA Auth Service. The JWT `iss` and `aud` claim values are fixed to the values emitted by the official service (`iss: 'auth-service'`, `aud: 'proyecto-global'`). These values are not configurable — they reflect the Auth Service contract and are intentional.

---

## Error Handling

All SDK operations return `Result<T>` — never throw for business flows:

```ts
import { isNotFound, isUnauthorized, getMessage } from '@eva_solutions/auth-sdk';

const result = await client.getUser(id);

if (!result.ok) {
  if (isNotFound(result.error)) return c.notFound();
  if (isUnauthorized(result.error)) return c.json({ error: 'Unauthorized' }, 401);
  return c.json({ error: getMessage(result.error) }, 500);
}

return c.json(result.data);
```

Available error helpers (re-exported from core):

```ts
// Type guards
isApiError(err), isSdkError(err)

// Generic matchers
matchError(err, code), matchSdkReason(err, reason)

// API shortcuts (12)
isNotFound, isUnauthorized, isForbidden, isConflict,
isValidationError, isRateLimited, isGone, isUnprocessableEntity,
isBadRequest, isInternalError, isServiceUnavailable, isAccountStateLocked

// SDK shortcuts (6)
isNetworkError, isTokenInvalid, isAuthRequired,
isRefreshNoTokens, isVerifyFailed, isMalformed
```

---

## Documentation

Full API reference, architecture diagrams, and configuration guide are available at:

**[https://eva-solutions-org.github.io/auth-sdk](https://eva-solutions-org.github.io/auth-sdk)**

Generated with TypeDoc + DMT theme. Source in `docs/`.

| Document | Contents |
|----------|----------|
| [docs/api.md](../../docs/api.md) | Complete API reference per entry point |
| [docs/architecture.md](../../docs/architecture.md) | Two-layer model, full auth flow, module structure |
| [docs/configuration.md](../../docs/configuration.md) | configureEvaAuth options (authUrl, cookieDomain, errorWire), build and distribution |
| [docs/security.md](../../docs/security.md) | Cookies, JWT, JWKS cache, deduplication |
| [docs/integrations.md](../../docs/integrations.md) | How the SDK fits the EVA system: consumers, cross-repo contracts, runtime Auth URL, releasing |
| [docs/migration.md](../../docs/migration.md) | Migration guides 2.x → 3.0.0 and 0.x → 1.0.0 |

---

## Security

Found a vulnerability? Please report it via [GitHub Security Advisories](https://github.com/eva-solutions-org/auth-sdk/security/advisories/new) or email `arturo.rodas.gonzales@gmail.com`. **Do not open a public issue for security reports.** See [SECURITY.md](../../SECURITY.md) for the full disclosure process and response timeline.

---

## Contributing

Contributions are welcome. See [CONTRIBUTING.md](../../CONTRIBUTING.md) for the development workflow, changeset process, and coding conventions. Please read [CODE_OF_CONDUCT.md](../../CODE_OF_CONDUCT.md) before participating.

---

## License

[MIT](./LICENSE) © 2026 EVA Solutions

---

*Built on [`jose`](https://github.com/panva/jose), [`hono`](https://hono.dev), [`react`](https://react.dev), and the broader TypeScript ecosystem.*
